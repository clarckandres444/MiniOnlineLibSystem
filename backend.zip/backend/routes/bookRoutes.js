const express = require("express");
const router = express.Router();
const Book = require("../models/Book");
const verifyToken = require("../middlewares/authMiddleware");
const isAdmin = require("../middlewares/roleMiddleware");

// View all books (everyone)
router.get("/", async (req, res) => {
  try {
    const books = await Book.find();
    res.json(books);
  } catch (err) {
    res.status(500).json({ message: "Error fetching books" });
  }
});

// Add book (admin only)
router.post("/add", verifyToken, isAdmin, async (req, res) => {
  try {
    const { title, author } = req.body;
    const newBook = new Book({ title, author });
    await newBook.save();
    res.json({ message: "Book added successfully!" });
  } catch (err) {
    res.status(500).json({ message: "Error adding book" });
  }
});

module.exports = router;
